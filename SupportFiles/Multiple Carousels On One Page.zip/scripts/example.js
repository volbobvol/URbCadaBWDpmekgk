$(document).ready(function() {

    var container1 = $('#container1');
	var container2 = $('#container2');
	var container3 = $('#container3');

    container1.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 2,
    });
	
	container2.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 2,
    });
	
	container3.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 2,
    });
});