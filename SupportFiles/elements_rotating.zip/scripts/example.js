$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        filter: ".ex-item",
        selectedIndex: 0,
        distance: 47,
        numberOfElementsToDisplayRight: 1,
        numberOfElementsToDisplayLeft: 1,
        designedForWidth: 1887,
        designedForHeight: 1057,
        path: {
                settings: {
                        shiftY: 533,
                        rotationAngleZY: -90,
                        a: 100,
                        b: 100,
                        endless: true
                },
                type: 'ellipse'
        },
        perspective: 956,
        sensitivity: 0.2,
        rotation: true,
        rotationBezierPoints: {
                p1: {
                        x: 0,
                        y: 0
                },
                p2: {
                        x: -1,
                        y: 90
                },
                p3: {
                        x: 94,
                        y: 90
                },
                p4: {
                        x: 100,
                        y: 0
                }
        },
        rotationVectorZ: 1,
        rotationNumberOfConfigurableElements: 4,
        rotationInvertForNegative: true
    });
});