$(document).ready(function() {

    var container = $('#container');


    container.theta_carousel({
        filter: ".ex-item",
        distance: 330,
        numberOfElementsToDisplayLeft: 0,
        path: {
                settings: {
                        shiftY: 55,
                        rotationAngleZY: 30
                },
                type: 'line'
        },
        perspective: 787,
        sensitivity: -1,
        verticalRotation: true
    });
    
});