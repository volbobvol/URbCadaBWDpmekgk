$(document).ready(function() {

    $('.th-container').theta_carousel({"filter": ".ex-item"});

});