Theta Carousel
Contributors: vdeveloper112
Donate link:
Tags: carousel, 3D slider, rotator, gallery, particle effect, slideshow
Requires at least: 4.6
Tested up to: 5.2
Stable tag: trunk
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Theta Carousel is a WordPress plug-in that helps you quickly and easily organize your images in 3D space.

== Description ==

This is a free version of a paind plugin -  http://theta-carousel.com/wp 
in the free version there is only one path evailable - elliptic, 
in the paid one there are many more paths spiral, line, parabola etc. 

Features:

* Variety of ready to use templates
* Visual configurator
* Responsive layout with auto scaling capability
* Endless rotation
* Autoplay
* Support for the key board, mouse and touch
* Elementor compatibility
* Fallback for browsers that do not support 3D transformations

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/theta-carousel` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Theta Carousel -> New Carousel to create a new carousel for your post


== Frequently Asked Questions ==

== Screenshots ==

1. /assets/Screenshot1.png
2. /assets/Screenshot2.png
3. /assets/Screenshot3.png
4. /assets/Screenshot4.png
5. /assets/Screenshot5.png
6. /assets/Screenshot6.png
7. /assets/Screenshot7.png
8. /assets/Screenshot8.png
9. /assets/Screenshot9.png
10. /assets/Screenshot10.png
11. /assets/Screenshot11.png
12. /assets/Screenshot12.png
13. /assets/Screenshot13.png
14. /assets/Screenshot14.png

== Changelog ==

= 1.0 =
* Initial release
