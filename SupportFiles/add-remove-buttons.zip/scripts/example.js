$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 20,
        "distance": 160,
        "numberOfElementsToDisplayRight": 6,
        "numberOfElementsToDisplayLeft": 3,
        "distanceInFallbackMode": 400,
        "designedForWidth": 1600,
        "designedForHeight": 705,
        "scaleX": 1.47,
        "scaleZ": 0.72,
        "path": {
            "settings": {
                "shiftX": 244,
                "shiftZ": -371,
                "rotationAngleZX": 9
            },
            "type": "line"
        },
        "perspective": 351,
        "sensitivity": -0.7,
        "shadow": true,
        "sizeAdjustment": true,
        "sizeAdjustmentNumberOfConfigurableElements": 7,
        "sizeAdjustmentBezierPoints": {
            "p1": {
                "x": 0,
                "y": 100
            },
            "p2": {
                "x": 58,
                "y": 94
            },
            "p3": {
                "x": 72,
                "y": 85
            },
            "p4": {
                "x": 100,
                "y": 55
            }
        },
        "popoutSelected": true,
        "popoutSelectedShiftX": -557,
        "popoutSelectedShiftZ": 288
    });
});

function addItem(){
	var container = $('#container');
	$('<div class="ex-item" style="background-color: #F7DE41">' +
            '<h1>Item ' + new Date() +'</h1>' +
            '<p>TEXT ' + new Date() +'</p>'+
        '</div>').appendTo(container);
		
	container.theta_carousel('update');
}

function removeLastItem(){
	var container = $('#container');
	var items = $('.ex-item', container);
	if(items.length != 0){
		$(items.get(0)).remove();
	}
	
	container.theta_carousel('update');
}