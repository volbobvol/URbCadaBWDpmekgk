
$(document).ready(function() {

    var container = $('#container');

    // fade in effect
    container.css({
        opacity: 0
    });
    container.delay(500).animate({
        opacity: 1
    }, 500);

    container.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 1,
        "distance": 40,
        "designedForWidth": 1344,
        "designedForHeight": 985,
        "distanceInFallbackMode": 550,
        "path": {
            "settings": {
                "shiftY": 197,
                "shiftZ": -1427,
                "rotationAngleZY": 19,
                "a": 833,
                "b": 835,
                "endless": true
            },
            "type": "ellipse"
        },
        "perspective": 956,
        "sensitivity": 0.2,
        "autorotation": true,
        "autorotationPause": 1500,
        "fadeAway": true,
        "fadeAwayBezierPoints": {
            "p1": {
                "x": 0,
                "y": 100
            },
            "p2": {
                "x": 41,
                "y": 67
            },
            "p3": {
                "x": 45,
                "y": 67
            },
            "p4": {
                "x": 100,
                "y": 33
            }
        },
        "sizeAdjustment": true,
        "sizeAdjustmentNumberOfConfigurableElements": 4,
        "sizeAdjustmentBezierPoints": {
            "p1": {
                "x": 0,
                "y": 100
            },
            "p2": {
                "x": 1,
                "y": 61
            },
            "p3": {
                "x": 5,
                "y": 72
            },
            "p4": {
                "x": 100,
                "y": 72
            }
        },
        "reflection": false,
        "reflectionBelow": 29
    });

    container
        .mouseenter(function() {
            container.theta_carousel({ 'autorotation': false });
        })
        .mouseleave(function() {
            container.theta_carousel({ 'autorotation': true });
        });

    $('a', container).each(function(index, item) {
        item = $(item);
        item.data('url', item.attr('href'));
        item.attr('href', 'javascript:void(0);');
    });

    $('a', container).click(function(e) {
        if ($(this).closest('.theta-carousel-element').hasClass('theta-current-item')) {
            // click on the item that is selected
            window.location = $(this).data('url');
        }
    })
});