$(document).ready(function() {

    var container = $('#container');


    // add handler that checks if link is located within selected element
    $('a', container).click(function () {

        var clickedOnElement = $(this).closest('.theta-carousel-element'); // get carousel element that contains clicked link
        var selectedIndex = $('#container').theta_carousel('option', 'selectedIndex'); // get current index
        var currentElement = $('.theta-carousel-element', container).get(selectedIndex);

        if (clickedOnElement.get(0) != currentElement)
            return false;
    })

    container.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 2,
        "distance": 125,
        "designedForWidth": 1920,
        "designedForHeight": 925,
        "scaleZ": 0.86,
        "distanceInFallbackMode": 250,
        "path": {
            "settings": {
                "shiftY": 201,
                "shiftZ": 440,
                "rotationAngleZY": -17,
                "wideness": 721
            },
            "type": "parabola"
        },
        "shadow": true,
        "shadowBlurRadius": 62,
        "shadowSpreadRadius": 2,
        "fadeAway": true,
        "fadeAwayBezierPoints": {
            "p1": {
                "x": 0,
                "y": 100
            },
            "p2": {
                "x": 97,
                "y": 97
            },
            "p3": {
                "x": 97,
                "y": 98
            },
            "p4": {
                "x": 100,
                "y": 0
            }
        }
    });
});