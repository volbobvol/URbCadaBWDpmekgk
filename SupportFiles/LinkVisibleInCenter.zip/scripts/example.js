$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 2,
        "distance": 125,
        "designedForWidth": 1920,
        "designedForHeight": 925,
        "scaleZ": 0.86,
        "distanceInFallbackMode": 250,
        "path": {
            "settings": {
                "shiftY": 201,
                "shiftZ": 440,
                "rotationAngleZY": -17,
                "wideness": 721
            },
            "type": "parabola"
        },
        "shadow": true,
        "shadowBlurRadius": 62,
        "shadowSpreadRadius": 2,
        "fadeAway": true,
        "fadeAwayBezierPoints": {
            "p1": {
                "x": 0,
                "y": 100
            },
            "p2": {
                "x": 97,
                "y": 97
            },
            "p3": {
                "x": 97,
                "y": 98
            },
            "p4": {
                "x": 100,
                "y": 0
            }
        }
    });
	
	function setCurrentItem(index){
		$('.ex-item', container).removeClass('current-item'); // remove current-item from all items
		$($('.ex-item', container).get(index)).addClass('current-item'); // add current-item only to current element
	}
	
	setCurrentItem(container.theta_carousel('option', 'selectedIndex'));
	
	container.on('motionStart', function(e, data){
		container.addClass('in-motion');
		setCurrentItem(data.index);
	});
	
	container.on('motionEnd', function(e, data){
		container.removeClass('in-motion');
		setCurrentItem(data.index);
	});
	
});