
$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        filter: ".ex-item",
        distance: 126,
        numberOfElementsToDisplayRight: 2,
        numberOfElementsToDisplayLeft: 2,
        path: {
                settings: {
                        rotationAngleZY: 90,
                        endless: true
                },
                type: 'line'
        },
        perspective: 787,
        sensitivity: -1,
        verticalRotation: true,
        sizeAdjustment: true,
        sizeAdjustmentNumberOfConfigurableElements: 2,
        sizeAdjustmentBezierPoints: {
                p1: {
                        x: 0,
                        y: 100
                },
                p2: {
                        x: 51,
                        y: 96
                },
                p3: {
                        x: 71,
                        y: 89
                },
                p4: {
                        x: 100,
                        y: 71
                }
        }
    });
});