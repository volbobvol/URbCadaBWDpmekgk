
$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        filter: ".ex-item",
         distance: 144,
        numberOfElementsToDisplayRight: 2,
        numberOfElementsToDisplayLeft: 2,
        path: {
                settings: {
                        rotationAngleXY: 90,
                        wideness: 421,
                        endless: true
                }
        },
        verticalRotation: true
    });
});