
$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        filter: ".ex-item",
        distance: 7,
        numberOfElementsToDisplayRight: 2,
        numberOfElementsToDisplayLeft: 2,
        scaleZ: 0.58,
        path: {
                settings: {
                        rotationAngleXY: 90,
                        a: 1000,
                        endless: true
                },
                type: 'ellipse'
        },
        perspective: 956,
        sensitivity: 0.2,
        verticalRotation: true,
        sizeAdjustment: true,
        sizeAdjustmentNumberOfConfigurableElements: 2,
        sizeAdjustmentBezierPoints: {
                p1: {
                        x: 0,
                        y: 100
                },
                p2: {
                        x: 43,
                        y: 91
                },
                p3: {
                        x: 51,
                        y: 89
                },
                p4: {
                        x: 100,
                        y: 73
                }
        }
    });
});