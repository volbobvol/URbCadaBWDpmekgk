
function carouselCreated(e, data) {
	
	// init youtube players
	
    var tag = $('<script></script>');
    tag.attr('src', 'https://www.youtube.com/iframe_api');
    tag.insertBefore($('script'));

    var onYouTubeIframeAPIReady = function() {
        $('.ex-item').each(function() {
                var video = $(this).data('video');
                var player = new YT.Player(video, {
                    height: '360',
                    width: '480',
                    videoId: video,
                    playerVars: {
                        autohide: 1,
                        theme: 'light'
                    },
                    events: {
                        'onReady': onPlayerReady,
                        'onStateChange': onPlayerStateChange
                    }
                });
            })
            .addClass('loading');
    };

    if (typeof(YT) == "undefined")
        window.onYouTubeIframeAPIReady = onYouTubeIframeAPIReady;
    else
        onYouTubeIframeAPIReady();
}

function indexChanged(){
	
	// pause all players when carousel slides
	
	$('.ex-item').each(function() {
        var player = $(this).data('player');
        if (player)
            player.pauseVideo();
    });
}

// this little trick with debounce 
// allows us to handle sequential status changes in youtube player 
// for example, when user slides a video forward 
// youtube raises three events: pause, loading, playing. And we can not distinguish  this from actual pause, when we should start autorotation

var debouncedPause = _.debounce(function(item, pause) {
	if(pause){
		item.data('status', '');
		// user just press pause button on the youtube player. we want to continue autorotation
		$('.theta-carousel').theta_carousel({autorotation: true});	
	}
}, 1000);

function onPlayerStateChange(event) {  

    var item = $(event.target.getIframe()).closest('.ex-item');

	var pause = false;
	
    if (!($('.theta-carousel').theta_carousel('getIsInMotion'))) {

        if (event.data === YT.PlayerState.PLAYING || event.data === YT.PlayerState.PAUSED || event.data === YT.PlayerState.ENDED || event.data === YT.PlayerState.UNSTARTED) {
            if (event.data === YT.PlayerState.PLAYING || event.data === YT.PlayerState.UNSTARTED) {
                item.data('status', 'playing');
                item.removeClass('loading');
                item.data('player', event.target);
				
				// user just press play button on the youtube player. we want to stop autorotation
				$('.theta-carousel').theta_carousel({autorotation: false});
            }

            if (event.data === YT.PlayerState.PAUSED || event.data === YT.PlayerState.ENDED) {
            	pause = true;
			}
        }

    }
	
	debouncedPause(item, pause);
};

function onPlayerReady(event) {
    var item = $(event.target.getIframe()).closest('.ex-item');
    if (item.hasClass('current')) {
       
    } else {
        $('.ex-item').removeClass('loading');
    }
}

$(document).ready(function() {

    var container = $('#container');

    // fade in effect
    container.css({
        opacity: 0
    });
    container.delay(500).animate({
        opacity: 1
    }, 500);

    container.theta_carousel({
        "filter": ".ex-item",
        "selectedIndex": 4,
        "designedForWidth": 1600,
        "designedForHeight": 729,
        "distance": 45,
        "distanceInFallbackMode": 550,
        "path": {
            "settings": {
                "shiftY": 136,
                "shiftZ": -1480,
                "rotateElements": true,
                "a": 1000,
                "b": 820,
                "endless": true
            },
            "type": "ellipse"
        },
        "perspective": 956,
        "sensitivity": 0.1,
		"autorotation": true,
        "autorotationPause": 2000,
        "allignElementsWithPath": true,
        "shadow": true,
        "popoutSelected": true,
        "popoutSelectedShiftY": -140,
        "popoutSelectedShiftZ": 741,
        "reflection": true,
        "reflectionBelow": 13,
        "reflectionHeight": 0.4
    });
    carouselCreated.call(container, null, {
        index: container.theta_carousel("option", "selectedIndex")
    });
    container.on('change', indexChanged);
});