$(document).ready(function() {

    var container = $('#container');

    container.theta_carousel({
        filter: ".ex-item",
        distance: 35,
        numberOfElementsToDisplayRight: 2,
        numberOfElementsToDisplayLeft: 2,
        designedForWidth: 762,
        designedForHeight: 1021,
        distanceInFallbackMode: 400,
        scaleY: 0.46,
        scaleZ: 0,
        path: {
                settings: {
                        shiftY: 72,
                        shiftZ: -227,
                        rotationAngleXY: 90,
                        rotationAngleZX: 36,
                        a: 1000,
                        b: 680,
                        endless: true
                },
                type: 'ellipse'
        },
        perspective: 956,
        sensitivity: 0.3,
        verticalRotation: true,
        sizeAdjustment: true,
        sizeAdjustmentNumberOfConfigurableElements: 3,
        sizeAdjustmentBezierPoints: {
                p1: {
                        x: 0,
                        y: 83
                },
                p2: {
                        x: 37,
                        y: 42
                },
                p3: {
                        x: 55,
                        y: 27
                },
                p4: {
                        x: 100,
                        y: 21
                }
        }
    });   
	
});